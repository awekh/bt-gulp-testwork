const gulp = require('gulp');
const plumber = require('gulp-plumber');
const rename = require('gulp-rename');
const autoprefixer = require('gulp-autoprefixer');
const babel = require('gulp-babel');
const concat = require('gulp-concat');
const eslint = require('gulp-eslint');
const uglify = require('gulp-uglify');
const rigger = require('gulp-rigger');
// const imagemin = require('gulp-imagemin'),
//     cache = require('gulp-cache');
const minifycss = require('gulp-minify-css');
const sass = require('gulp-sass');
const browsersync = require('browser-sync').create();

// BrowserSync
    function bsInit(done) {
        browsersync.init({
            server: {
                baseDir: "./"
            }
        });
        done();
    }

// BrowserSync Reload
function bsReload(done) {
    browsersync.reload();
    done();
}

// Optimize Images.
function images() {
    'use strict';
    return gulp.src('src/images/**/*')
        .pipe(gulp.dest('dist/images/'));
    }

// Compile CSS
function styles() {
    'use strict';
    return gulp.src(['src/styles/**/*.scss'])
        .pipe(plumber())
        .pipe(sass())
        .pipe(autoprefixer())
        .pipe(gulp.dest('dist/styles/'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(minifycss())
        .pipe(gulp.dest('dist/styles/'))
        .pipe(browsersync.stream());
}

// Move fonts
function fonts() {
    'use strict';
    return gulp.src(['src/fonts/**/*'])
        .pipe(gulp.dest('dist/fonts/'))
}

// Concatenate, minify, and lint scripts
function scripts() {
    'use strict';
    return gulp.src('src/scripts/**/*.js')
        .pipe(rigger())
        .pipe(plumber())
        .pipe(eslint())
        .pipe(eslint.format())
        .pipe(eslint.failAfterError())
        .pipe(concat('main.js'))
        .pipe(gulp.dest('dist/scripts/'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(uglify())
        .pipe(gulp.dest('dist/scripts/'))
        .pipe(browsersync.stream());
}

// Watch Files
function watchFiles() {
    'use strict';
    gulp.watch("src/styles/**/*.scss", styles);
    gulp.watch('src/scripts/**/*.js', scripts);
    gulp.watch("src/images/**/*", images);
    gulp.watch('src/fonts/**/*', fonts);
    gulp.watch('*.html', bsReload);
}

// Group complex tasks
const build = gulp.parallel(styles, scripts, fonts, images);
const watch = gulp.parallel(watchFiles, bsInit);

// Export tasks
exports.build = build;
exports.images = images;
exports.scripts = scripts;
exports.styles = styles;
exports.fonts = fonts;
exports.watch = watch;
exports.default = watch;
