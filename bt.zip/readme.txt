npm i
gulp
gulp watch
enjoy