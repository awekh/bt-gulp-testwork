

//= ../../node_modules/bootstrap/js/dist/index.js
//= ../../node_modules/bootstrap/js/dist/util.js
//= ../../node_modules/bootstrap/js/dist/collapse.js